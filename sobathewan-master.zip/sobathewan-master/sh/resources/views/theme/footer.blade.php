<footer id="footer" class="dark">
    <div class="container">
        <!-- Footer Widgets ============================================= -->
        <div class="footer-widgets-wrap">
            <div class="row col-mb-50">
                <div class="col-lg-8">
                    <div class="row col-mb-50">
                        <div class="col-md-4">
                            <div class="widget clearfix">
                                <h4>SobatHewan</h4>
                                <p>  </p>
                                <div>
                                    <address>
                                        <strong>Sitoluama:</strong><br>
                                        Laguboti<br>
                                        IT Del<br>
                                    </address>
                                    <abbr title="Phone Number"><strong></strong></abbr> <br>
                                    <abbr title="Fax"><strong></strong></abbr><br>
                                    <abbr title="Email Address"><strong></strong></abbr>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="widget widget_links clearfix">
                                <h4></h4>
                                <ul>
                                    <li><a href="https://codex.wordpress.org/"></a></li>
                                    <li><a href="https://wordpress.org/support/forum/requests-and-feedback"></a></li>
                                    <li><a href="https://wordpress.org/extend/plugins/"></a></li>
                                    <li><a href="https://wordpress.org/support/"></a></li>
                                    <li><a href="https://wordpress.org/extend/themes/"></a></li>
                                    <li><a href="https://wordpress.org/news/"></a></li>
                                    <li><a href="https://planet.wordpress.org/"></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="widget clearfix">
                                <h4></h4>
                                <div class="posts-sm row col-mb-30" id="post-list-footer">
                                    <div class="entry col-12">
                                        <div class="grid-inner row">
                                            <div class="col">
                                                <div class="entry-title">
                                                    <h4><a href="#"></a></h4>
                                                </div>
                                                <div class="entry-meta">
                                                    <ul>
                                                        <li></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="entry col-12">
                                        <div class="grid-inner row">
                                            <div class="col">
                                                <div class="entry-title">
                                                    <h4><a href="#"></a></h4>
                                                </div>
                                                <div class="entry-meta">
                                                    <ul>
                                                        <li></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="entry col-12">
                                        <div class="grid-inner row">
                                            <div class="col">
                                                <div class="entry-title">
                                                    <h4><a href="#"></a></h4>
                                                </div>
                                                <div class="entry-meta">
                                                    <ul>
                                                        <li></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="row col-mb-50">
                        <div class="col-md-4 col-lg-12">
                            <div class="widget clearfix" style="margin-bottom: -20px;">
                                <div class="row">
                                    <div class="col-lg-6 bottommargin-sm">
                                        <div class="counter counter-small"></div>
                                        <h5 class="mb-0"></h5>
                                    </div>
                                    <div class="col-lg-6 bottommargin-sm">
                                        <div class="counter counter-small"></div>
                                        <h5 class="mb-0"></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5 col-lg-12">
                            <div class="widget subscribe-widget clearfix">
                                <h5><strong></strong>  </h5>
                                <div class="widget-subscribe-form-result"></div>
                                <form id="widget-subscribe-form" action="include/subscribe.php" method="post" class="mb-0">
                                    <div class="input-group mx-auto">
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-md-3 col-lg-12">
                            <div class="widget clearfix" style="margin-bottom: -20px;">
                                <div class="row">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- .footer-widgets-wrap end -->
    </div>
    <!-- Copyrights ============================================= -->
    <div id="copyrights">
        <div class="container">
            <div class="row col-mb-30">
                <div class="col-md-6 text-center text-md-left">
                    Copyrights &copy; Kelompok 7.<br>
                    <div class="copyright-links"><a href="#"></a> <a href="#"></a></div>
                </div>
                <div class="col-md-6 text-center text-md-right">
                    </div>
                    <div class="clear"></div>
                </div>

            </div>

        </div>
    </div>
    <!-- #copyrights end -->
</footer>
